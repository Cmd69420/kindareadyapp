package com.bluemix.clients_lead.core.common.extensions


import com.bluemix.clients_lead.core.common.utils.AppError
import io.github.jan.supabase.auth.exception.AuthRestException
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

//
//fun Throwable.toAppError(): AppError = when (this) {
//    is AuthRestException -> when (statusCode) {
//        400, 422 -> AppError.Validation(message = description ?: error ?: "Invalid request", code = error, cause = this)
//        401      -> AppError.Unauthorized(cause = this)
//        403      -> AppError.Forbidden(cause = this)
//        404      -> AppError.NotFound(cause = this)
//        409      -> AppError.Validation(message = description ?: "Conflict", code = error, cause = this)
//        429      -> AppError.RateLimited(message = description ?: "Too many requests", cause = this)
//        500,503  -> AppError.ServiceUnavailable(cause = this)
//        else     -> AppError.Unknown(cause = this)
//    }
//    is IOException -> AppError.Network(cause = this)
//    else -> AppError.Unknown(cause = this)
//}

fun Throwable.toAppError(): AppError = when (this) {
    is AuthRestException -> when (statusCode) {
        400, 422 -> AppError.Validation(
            message = description ?: error ?: "Invalid request",
            code = error,
            cause = this
        )

        401 -> AppError.Unauthorized(cause = this)
        403 -> AppError.Forbidden(cause = this)
        404 -> AppError.NotFound(cause = this)
        408 -> AppError.Network(message = "Request timeout", cause = this)
        409 -> AppError.Validation(message = description ?: "Conflict", code = error, cause = this)
        429 -> {
            // Parse retry-after header if available
            val retryAfter = (this as? AuthRestException)?.let {
                // Extract from error details if available
                null // Supabase doesn't expose headers easily
            }
            AppError.RateLimited(
                message = description ?: "Too many requests",
                retryAfterSeconds = retryAfter,
                cause = this
            )
        }

        500, 502, 503, 504 -> AppError.ServiceUnavailable(cause = this)
        else -> AppError.Unknown(cause = this)
    }

    is IOException -> AppError.Network(cause = this)
    is CancellationException -> throw this  // ⚠️ IMPORTANT: Never catch cancellation
    else -> AppError.Unknown(cause = this)
}
