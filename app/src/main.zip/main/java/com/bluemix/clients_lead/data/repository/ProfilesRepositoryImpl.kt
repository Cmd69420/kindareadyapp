package com.bluemix.clients_lead.data.repository

import android.content.Context
import android.util.Log
import com.bluemix.clients_lead.core.common.extensions.runAppCatching
import com.bluemix.clients_lead.core.common.extensions.toAppError
import com.bluemix.clients_lead.core.common.utils.AppResult
import com.bluemix.clients_lead.data.mapper.toDomain
import com.bluemix.clients_lead.data.models.ProfileDto
import com.bluemix.clients_lead.data.models.ProfileInsertDto
import com.bluemix.clients_lead.data.models.ProfileUpdateDto
import com.bluemix.clients_lead.domain.model.LocationTrackingPreference
import com.bluemix.clients_lead.domain.model.UserProfile
import com.bluemix.clients_lead.domain.repository.IProfileRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TAG = "ProfileRepository"

class ProfileRepositoryImpl(
    private val supabase: SupabaseClient,
    private val context: Context
) : IProfileRepository {

    private val prefs by lazy {
        context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
    }

    override suspend fun getProfile(userId: String): AppResult<UserProfile> =
        withContext(Dispatchers.IO) {
            Log.d(TAG, "Getting profile for userId: $userId")

            runAppCatching(mapper = Throwable::toAppError) {
                val profile = supabase.from("profiles")
                    .select {
                        filter { eq("id", userId) }
                    }
                    .decodeSingle<ProfileDto>()

                profile.toDomain()
            }.also { result ->
                when (result) {
                    is AppResult.Success -> Log.d(TAG, "Profile loaded successfully")
                    is AppResult.Error -> Log.e(
                        TAG,
                        "Failed to load profile: ${result.error.message}",
                        result.error.cause
                    )
                }
            }
        }

    override suspend fun updateProfile(
        userId: String,
        fullName: String?,
        department: String?,
        workHoursStart: String?,
        workHoursEnd: String?
    ): AppResult<UserProfile> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val updateDto = ProfileUpdateDto(
                fullName = fullName,
                department = department,
                workHoursStart = workHoursStart,
                workHoursEnd = workHoursEnd
            )

            val updatedProfile = supabase.from("profiles")
                .update(updateDto) {
                    filter { eq("id", userId) }
                    select()
                }
                .decodeSingle<ProfileDto>()

            updatedProfile.toDomain()
        }
    }

    override suspend fun createProfile(
        userId: String,
        email: String?,
        fullName: String?
    ): AppResult<UserProfile> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val insertDto = ProfileInsertDto(
                id = userId,
                email = email,
                fullName = fullName
            )

            val createdProfile = supabase.from("profiles")
                .insert(insertDto) {
                    select()
                }
                .decodeSingle<ProfileDto>()

            createdProfile.toDomain()
        }
    }

    override suspend fun getLocationTrackingPreference(): LocationTrackingPreference {
        val isEnabled = prefs.getBoolean("location_tracking_enabled", false)
        return LocationTrackingPreference(isEnabled)
    }

    override suspend fun saveLocationTrackingPreference(enabled: Boolean) {
        prefs.edit().putBoolean("location_tracking_enabled", enabled).apply()
    }
}

//private const val TAG = "ProfileRepository"
//
//class ProfileRepositoryImpl(
//    private val supabase: SupabaseClient,
//    private val context: Context
//) : IProfileRepository {
//
//    private val prefs by lazy {
//        context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
//    }
//
//    override suspend fun getProfile(userId: String): AppResult<UserProfile> =
//        withContext(Dispatchers.IO) {
//            Log.d(TAG, "🗄️ getProfile called with userId: $userId")
//
//            runAppCatching(mapper = Throwable::toAppError) {
//                Log.d(TAG, "🗄️ Querying profiles table...")
//                Log.d(TAG, "🗄️ Query: SELECT * FROM profiles WHERE id = '$userId'")
//
//                val profile = supabase.from("profiles")
//                    .select {
//                        filter {
//                            eq("id", userId)
//                        }
//                    }
//                    .decodeSingle<ProfileDto>()
//
//                Log.d(TAG, "🗄️ Raw ProfileDto from Supabase: $profile")
//
//                val domainProfile = profile.toDomain()
//                Log.d(TAG, "🗄️ Mapped to UserProfile: $domainProfile")
//
//                domainProfile
//            }.also { result ->
//                when (result) {
//                    is AppResult.Success -> Log.d(TAG, "✅ getProfile SUCCESS")
//                    is AppResult.Error -> {
//                        Log.e(TAG, "❌ getProfile FAILED: ${result.error.message}")
//                        Log.e(TAG, "❌ Throwable: ${result.error.cause?.message}")
//                        result.error.cause?.printStackTrace()
//                    }
//                }
//            }
//        }
//
//    override suspend fun updateProfile(
//        userId: String,
//        fullName: String?,
//        department: String?,
//        workHoursStart: String?,
//        workHoursEnd: String?
//    ): AppResult<UserProfile> = withContext(Dispatchers.IO) {
//        Log.d(TAG, "🗄️ updateProfile called")
//        runAppCatching(mapper = Throwable::toAppError) {
//            val updateDto = ProfileUpdateDto(
//                fullName = fullName,
//                department = department,
//                workHoursStart = workHoursStart,
//                workHoursEnd = workHoursEnd
//            )
//
//            val updatedProfile = supabase.from("profiles")
//                .update(updateDto) {
//                    filter {
//                        eq("id", userId)
//                    }
//                    select()
//                }
//                .decodeSingle<ProfileDto>()
//
//            updatedProfile.toDomain()
//        }
//    }
//
//    override suspend fun createProfile(
//        userId: String,
//        email: String?,
//        fullName: String?
//    ): AppResult<UserProfile> = withContext(Dispatchers.IO) {
//        Log.d(TAG, "🗄️ createProfile called")
//        runAppCatching(mapper = Throwable::toAppError) {
//            val insertDto = ProfileInsertDto(
//                id = userId,
//                email = email,
//                fullName = fullName
//            )
//
//            val createdProfile = supabase.from("profiles")
//                .insert(insertDto) {
//                    select()
//                }
//                .decodeSingle<ProfileDto>()
//
//            createdProfile.toDomain()
//        }
//    }
//
//    override suspend fun getLocationTrackingPreference(): LocationTrackingPreference {
//        val isEnabled = prefs.getBoolean("location_tracking_enabled", false)
//        return LocationTrackingPreference(isEnabled)
//    }
//
//    override suspend fun saveLocationTrackingPreference(enabled: Boolean) {
//        prefs.edit().putBoolean("location_tracking_enabled", enabled).apply()
//    }
//}

