package com.bluemix.clients_lead.core.network

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage
import io.ktor.client.engine.okhttp.OkHttp

object SupabaseClientProvider {
    fun create(url: String, anonKey: String, scheme: String, host: String): SupabaseClient =
        createSupabaseClient(supabaseUrl = url, supabaseKey = anonKey) {
            httpEngine = OkHttp.create()
            install(Auth.Companion) {
                this.scheme = scheme
                this.host = host
            }
            install(Postgrest.Companion)
            install(Storage.Companion)
        }
}