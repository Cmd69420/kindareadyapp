package com.bluemix.clients_lead.data.repository

import com.bluemix.clients_lead.core.common.extensions.runAppCatching
import com.bluemix.clients_lead.core.common.extensions.toAppError
import com.bluemix.clients_lead.core.common.utils.AppResult
import com.bluemix.clients_lead.data.mapper.toDomain
import com.bluemix.clients_lead.data.models.ClientDto
import com.bluemix.clients_lead.domain.model.Client
import com.bluemix.clients_lead.domain.repository.IClientRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ClientRepositoryImpl(
    private val supabase: SupabaseClient
) : IClientRepository {

    override suspend fun getAllClients(userId: String): AppResult<List<Client>> =
        withContext(Dispatchers.IO) {
            runAppCatching(mapper = Throwable::toAppError) {
                val clients = supabase.from("clients")
                    .select {
                        filter {
                            eq("created_by", userId)
                        }
                        order("created_at", order = Order.DESCENDING)
                    }
                    .decodeList<ClientDto>()

                clients.toDomain()
            }
        }

    override suspend fun getClientsByStatus(
        userId: String,
        status: String
    ): AppResult<List<Client>> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val clients = supabase.from("clients")
                .select {
                    filter {
                        eq("created_by", userId)
                        eq("status", status)
                    }
                    order("name", order = Order.ASCENDING)
                }
                .decodeList<ClientDto>()

            clients.toDomain()
        }
    }

    override suspend fun getClientsWithLocation(userId: String): AppResult<List<Client>> =
        withContext(Dispatchers.IO) {
            runAppCatching(mapper = Throwable::toAppError) {
                val clients = supabase.from("clients")
                    .select {
                        filter {
                            eq("created_by", userId)
                            eq("has_location", true)
                        }
                    }
                    .decodeList<ClientDto>()

                clients.toDomain()
            }
        }

    override suspend fun getClientById(clientId: String): AppResult<Client> =
        withContext(Dispatchers.IO) {
            runAppCatching(mapper = Throwable::toAppError) {
                val client = supabase.from("clients")
                    .select {
                        filter {
                            eq("id", clientId)
                        }
                    }
                    .decodeSingle<ClientDto>()

                client.toDomain()
            }
        }

    override suspend fun searchClients(
        userId: String,
        query: String
    ): AppResult<List<Client>> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val clients = supabase.from("clients")
                .select {
                    filter {
                        eq("created_by", userId)
                        ilike("name", "%$query%")
                    }
                }
                .decodeList<ClientDto>()

            clients.toDomain()
        }
    }
}
