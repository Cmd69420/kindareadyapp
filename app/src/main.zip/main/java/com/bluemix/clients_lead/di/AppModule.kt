package com.bluemix.clients_lead.di

import com.bluemix.clients_lead.BuildConfig
import com.bluemix.clients_lead.core.common.utils.DefaultDispatchers
import com.bluemix.clients_lead.core.common.utils.DispatcherProvider
import com.bluemix.clients_lead.core.network.SupabaseClientProvider
import com.bluemix.clients_lead.features.auth.vm.SessionViewModel
import com.bluemix.clients_lead.features.map.vm.MapViewModel
import io.github.jan.supabase.SupabaseClient
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {

    // Core Infrastructure
    single<DispatcherProvider> { DefaultDispatchers }

    // Supabase Client
    single<SupabaseClient> {
        SupabaseClientProvider.create(
            url = BuildConfig.SUPABASE_URL,
            anonKey = BuildConfig.SUPABASE_ANON_KEY,
            scheme = "clientslead",
            host = "auth"
        )
    }

    // Cross-feature ViewModels (used by multiple features)
    viewModel { SessionViewModel(get(), get()) }
    viewModel { MapViewModel(get(), get()) }
}
