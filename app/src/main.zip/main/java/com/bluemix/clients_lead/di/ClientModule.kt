package com.bluemix.clients_lead.di

import com.bluemix.clients_lead.data.repository.ClientRepositoryImpl
import com.bluemix.clients_lead.domain.repository.IClientRepository
import com.bluemix.clients_lead.domain.usecases.GetAllClients
import com.bluemix.clients_lead.domain.usecases.GetClientById
import com.bluemix.clients_lead.domain.usecases.GetClientsWithLocation
import com.bluemix.clients_lead.domain.usecases.SearchClients
import com.bluemix.clients_lead.features.Clients.vm.ClientDetailViewModel
import com.bluemix.clients_lead.features.Clients.vm.ClientsViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val clientModule = module {
    // Repository
    single<IClientRepository> { ClientRepositoryImpl(get()) }

    // Use Cases
    factory { GetAllClients(get()) }
    factory { GetClientById(get()) }
    factory { GetClientsWithLocation(get()) }
    factory { SearchClients(get()) }

    // ViewModels
    viewModel { ClientsViewModel(get(), get()) }
    viewModel { ClientDetailViewModel(get()) }
}
