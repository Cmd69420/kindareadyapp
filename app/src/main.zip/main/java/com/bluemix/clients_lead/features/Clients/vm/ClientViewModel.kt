package com.bluemix.clients_lead.features.Clients.vm


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bluemix.clients_lead.core.common.utils.AppResult
import com.bluemix.clients_lead.domain.model.Client
import com.bluemix.clients_lead.domain.usecases.GetCurrentUserId
import com.bluemix.clients_lead.domain.usecases.GetAllClients
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber

enum class ClientFilter {
    ALL, ACTIVE, INACTIVE, COMPLETED
}

data class ClientsUiState(
    val isLoading: Boolean = false,
    val clients: List<Client> = emptyList(),
    val filteredClients: List<Client> = emptyList(),
    val selectedFilter: ClientFilter = ClientFilter.ACTIVE,
    val searchQuery: String = "",
    val error: String? = null
)

/**
 * ViewModel for clients list screen.
 * Uses use cases for data access and proper error handling.
 */
class ClientsViewModel(
    private val getAllClients: GetAllClients,
    private val getCurrentUserId: GetCurrentUserId
) : ViewModel() {

    private val _uiState = MutableStateFlow(ClientsUiState())
    val uiState: StateFlow<ClientsUiState> = _uiState.asStateFlow()

    init {
        loadClients()
    }

    fun loadClients() {
        viewModelScope.launch {
            Timber.d("Loading clients...")
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            // Get current user ID from auth repository
            val userId = getCurrentUserId()
            if (userId == null) {
                Timber.e("User not authenticated")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "User not authenticated"
                )
                return@launch
            }

            Timber.d("Loading clients for user: $userId")

            when (val result = getAllClients(userId)) {
                is AppResult.Success -> {
                    val clients = result.data
                    Timber.d("Successfully loaded ${clients.size} clients")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        clients = clients,
                        filteredClients = filterClients(clients, ClientFilter.ACTIVE, "")
                    )
                }

                is AppResult.Error -> {
                    Timber.e(
                        result.error.message,
                        "Failed to load clients: ${result.error.message}"
                    )
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = result.error.message ?: "Failed to load clients"
                    )
                }
            }
        }
    }

    fun setFilter(filter: ClientFilter) {
        val filtered = filterClients(
            _uiState.value.clients,
            filter,
            _uiState.value.searchQuery
        )
        _uiState.value = _uiState.value.copy(
            selectedFilter = filter,
            filteredClients = filtered
        )
    }

    fun searchClients(query: String) {
        val filtered = filterClients(
            _uiState.value.clients,
            _uiState.value.selectedFilter,
            query
        )
        _uiState.value = _uiState.value.copy(
            searchQuery = query,
            filteredClients = filtered
        )
    }

    private fun filterClients(
        clients: List<Client>,
        filter: ClientFilter,
        query: String
    ): List<Client> {
        var filtered = when (filter) {
            ClientFilter.ALL -> clients
            ClientFilter.ACTIVE -> clients.filter { it.status == "active" }
            ClientFilter.INACTIVE -> clients.filter { it.status == "inactive" }
            ClientFilter.COMPLETED -> clients.filter { it.status == "completed" }
        }

        if (query.isNotBlank()) {
            filtered = filtered.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.email?.contains(query, ignoreCase = true) == true ||
                        it.phone?.contains(query, ignoreCase = true) == true
            }
        }

        return filtered
    }

    fun refresh() {
        loadClients()
    }
}
