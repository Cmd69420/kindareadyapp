package com.bluemix.clients_lead.data.repository

import android.net.Uri
import com.bluemix.clients_lead.core.common.extensions.runAppCatching
import com.bluemix.clients_lead.core.common.extensions.toAppError
import com.bluemix.clients_lead.core.common.utils.AppResult
import com.bluemix.clients_lead.domain.repository.AuthRepository
import com.bluemix.clients_lead.domain.repository.AuthUser
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.parseSessionFromUrl
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.providers.builtin.OTP
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

class AuthRepositoryImpl(
    private val client: SupabaseClient
) : AuthRepository {

    override suspend fun signIn(email: String, password: String): AppResult<Unit> =
        runAppCatching(mapper = Throwable::toAppError) {
            client.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
        }

    override suspend fun signUp(email: String, password: String): AppResult<Unit> =
        runAppCatching(mapper = Throwable::toAppError) {
            client.auth.signUpWith(Email) {
                this.email = email
                this.password = password
            }
        }

    override suspend fun signOut(): AppResult<Unit> =
        runAppCatching(mapper = Throwable::toAppError) {
            client.auth.signOut()
        }

    override suspend fun isLoggedIn(): Boolean =
        client.auth.currentSessionOrNull() != null

    override suspend fun currentUserId(): String? =
        client.auth.currentUserOrNull()?.id

    override suspend fun sendMagicLink(email: String, redirectUrl: String?): AppResult<Unit> =
        runAppCatching(mapper = Throwable::toAppError) {
            client.auth.signInWith(OTP, redirectUrl = redirectUrl) {
                this.email = email
            }
        }

    override fun authState(): Flow<AuthUser?> {
        return client.auth.sessionStatus
            .map { status ->
                when (status) {
                    is SessionStatus.Authenticated -> AuthUser(
                        id = status.session.user?.id ?: return@map null,
                        email = status.session.user?.email
                    )
                    else -> null
                }
            }
            .distinctUntilChanged()
    }

    override suspend fun handleAuthRedirect(redirectUrl: String): AppResult<Unit> =
        runAppCatching(mapper = Throwable::toAppError) {
            when {
                redirectUrl.contains("code=") -> {
                    val code = Uri.parse(redirectUrl).getQueryParameter("code")
                        ?: error("No code in redirect URL")
                    client.auth.exchangeCodeForSession(code)
                }

                redirectUrl.contains("access_token") -> {
                    val session = client.auth.parseSessionFromUrl(redirectUrl)
                    client.auth.importSession(session)
                }

                else -> error("Redirect URL doesn't contain recognized auth parameters")
            }
        }
}

//
//class AuthRepositoryImpl(
//    private val client: SupabaseClient
//) : AuthRepository {
//
//    override suspend fun signIn(email: String, password: String): AppResult<Unit> =
//        runAppCatching(mapper = Throwable::toAppError) {
//            client.auth.signInWith(Email) {
//                this.email = email
//                this.password = password
//            }
//        }
//
//    override suspend fun signUp(email: String, password: String): AppResult<Unit> =
//        runAppCatching(mapper = Throwable::toAppError) {
//            client.auth.signUpWith(Email) {
//                this.email = email
//                this.password = password
//            }
//            Unit
//        }
//
//    override suspend fun signOut(): AppResult<Unit> =
//        runAppCatching(mapper = Throwable::toAppError) {
//            client.auth.signOut()
//        }
//
//    override suspend fun isLoggedIn(): Boolean =
//        runCatching { client.auth.currentSessionOrNull() != null }.getOrDefault(false)
//
//    override suspend fun currentUserId(): String? =
//        runCatching { client.auth.currentUserOrNull()?.id }.getOrNull()
//
//    override suspend fun sendMagicLink(email: String, redirectUrl: String?): AppResult<Unit> =
//        runAppCatching(mapper = { it.toAppError() }) {
//            client.auth.signInWith(OTP, redirectUrl = redirectUrl) {
//                this.email = email
//            }
//        }
//
//    override fun authState(): Flow<AuthUser?> {
//        return client.auth.sessionStatus
//            .map { status ->
//                when (status) {
//                    is SessionStatus.Authenticated -> status.session.user?.let { u ->
//                        AuthUser(id = u.id, email = u.email)
//                    }
//
//                    else -> null  // Covers all non-authenticated states
//                }
//            }
//            .distinctUntilChanged()
//    }
//
//    override suspend fun handleAuthRedirect(redirectUrl: String): AppResult<Unit> =
//        runAppCatching(mapper = { it.toAppError() }) {
//            // Let Supabase handle the parsing
//            when {
//                redirectUrl.contains("code=") -> {
//                    // PKCE flow
//                    val code = Uri.parse(redirectUrl).getQueryParameter("code")
//                        ?: error("No code in redirect URL")
//                    client.auth.exchangeCodeForSession(code)
//                }
//
//                redirectUrl.contains("access_token") -> {
//                    // Magic link / OTP flow
//                    val session = client.auth.parseSessionFromUrl(redirectUrl)
//                    client.auth.importSession(session)
//                }
//
//                else -> error("Redirect URL doesn't contain recognized auth parameters.")
//            }
//        }
//}
