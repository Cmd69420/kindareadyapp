package com.bluemix.clients_lead.data.repository

import com.bluemix.clients_lead.core.common.extensions.runAppCatching
import com.bluemix.clients_lead.core.common.extensions.toAppError
import com.bluemix.clients_lead.core.common.utils.AppResult
import com.bluemix.clients_lead.data.mapper.toDomain
import com.bluemix.clients_lead.data.models.LocationLogDto
import com.bluemix.clients_lead.data.models.LocationLogInsertDto
import com.bluemix.clients_lead.domain.model.LocationLog
import com.bluemix.clients_lead.domain.repository.ILocationRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


class LocationRepositoryImpl(
    private val supabase: SupabaseClient
) : ILocationRepository {

    override suspend fun insertLocationLog(
        userId: String,
        latitude: Double,
        longitude: Double,
        accuracy: Double?
    ): AppResult<LocationLog> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val logToInsert = LocationLogInsertDto(
                userId = userId,
                latitude = latitude,
                longitude = longitude,
                accuracy = accuracy
            )

            val insertedLog = supabase.from("location_logs")
                .insert(logToInsert) {
                    select()
                }
                .decodeSingle<LocationLogDto>()

            insertedLog.toDomain()
        }
    }

    override suspend fun getLocationLogs(
        userId: String,
        limit: Int
    ): AppResult<List<LocationLog>> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val logs = supabase.from("location_logs")
                .select {
                    filter {
                        eq("user_id", userId)
                    }
                    order("timestamp", order = Order.DESCENDING)
                    limit(limit.toLong())
                }
                .decodeList<LocationLogDto>()

            logs.toDomain()
        }
    }

    override suspend fun getLocationLogsByDateRange(
        userId: String,
        startDate: String,
        endDate: String
    ): AppResult<List<LocationLog>> = withContext(Dispatchers.IO) {
        runAppCatching(mapper = Throwable::toAppError) {
            val logs = supabase.from("location_logs")
                .select {
                    filter {
                        eq("user_id", userId)
                        gte("timestamp", startDate)
                        lte("timestamp", endDate)
                    }
                    order("timestamp", order = Order.DESCENDING)
                }
                .decodeList<LocationLogDto>()

            logs.toDomain()
        }
    }

    override suspend fun deleteOldLogs(olderThanDays: Int): AppResult<Int> =
        withContext(Dispatchers.IO) {
            runAppCatching(mapper = Throwable::toAppError) {
                // Calculate date threshold
                val calendar = java.util.Calendar.getInstance()
                calendar.add(java.util.Calendar.DAY_OF_YEAR, -olderThanDays)
                val threshold =
                    java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
                        .format(calendar.time)

                supabase.from("location_logs")
                    .delete {
                        filter {
                            lt("timestamp", threshold)
                        }
                    }

                0 // Supabase doesn't return count
            }
        }
}
